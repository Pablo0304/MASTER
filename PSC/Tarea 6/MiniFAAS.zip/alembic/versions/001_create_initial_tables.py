from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "001_create_initial_tables"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    encargo_status = sa.Enum(
        "PENDIENTE", "EN_EJECUCION", "OK", "ERROR", name="encargo_status"
    )
    encargo_status.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "lambdas",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            nullable=False,
        ),
        sa.Column("nombre", sa.String(length=255), nullable=False),
        sa.Column("runtime", sa.String(length=50), nullable=False),
        sa.Column("owner_id", sa.String(length=255), nullable=True),
        sa.Column("code_ref", sa.String(length=1024), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
    )

    op.create_table(
        "encargos",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            nullable=False,
        ),
        sa.Column(
            "lambda_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("lambdas.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("input_ref", sa.String(length=1024), nullable=False),
        sa.Column("status", encargo_status, nullable=False, server_default="PENDIENTE"),
        sa.Column("worker_id", sa.String(length=255), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error_msg", sa.Text(), nullable=True),
    )
    op.create_index(
        "ix_encargos_status",
        "encargos",
        ["status"],
    )
    op.create_index(
        "ix_encargos_lambda_id",
        "encargos",
        ["lambda_id"],
    )

    op.create_table(
        "resultados",
        sa.Column(
            "encargo_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("encargos.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        ),
        sa.Column("exit_code", sa.Integer(), nullable=False),
        sa.Column("stdout_ref", sa.String(length=1024), nullable=False),
        sa.Column("stderr_ref", sa.String(length=1024), nullable=False),
        sa.Column("output_ref", sa.String(length=1024), nullable=True),
    )


def downgrade() -> None:
    op.drop_table("resultados")
    op.drop_index("ix_encargos_lambda_id", table_name="encargos")
    op.drop_index("ix_encargos_status", table_name="encargos")
    op.drop_table("encargos")
    op.drop_table("lambdas")
    encargo_status = sa.Enum(
        "PENDIENTE", "EN_EJECUCION", "OK", "ERROR", name="encargo_status"
    )
    encargo_status.drop(op.get_bind(), checkfirst=True)

