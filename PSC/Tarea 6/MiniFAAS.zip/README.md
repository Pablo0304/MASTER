# Mini-FaaS

## Levantar la infraestructura

```bash
docker compose up --build
```

## Ejemplo de uso vía curl

### 1. Subir una lambda de ejemplo

```bash
cat > lambda_example.py <<'EOF'
import sys

def main():
    data = sys.stdin.read().strip()
    n = int(data)
    print(n * 2)

if __name__ == "__main__":
    main()
EOF

META='{"nombre": "doble", "runtime": "python", "ownerId": null}'

curl -X POST "http://localhost:8080/guardar_lambda" \
  -F "file=@lambda_example.py;type=text/x-python" \
  -F "meta=${META}"
```

### 2. Listar lambdas

```bash
curl http://localhost:8080/lambdas
```

### 3. Dejar un encargo

```bash
DATA_BASE64=$(python - <<'EOF'
import base64
print(base64.b64encode(b"21").decode("ascii"))
EOF
)

ID_LAMBDA="<uuid-devuelto>"
curl -X POST http://localhost:8080/dejar_encargo \
  -H "Content-Type: application/json" \
  -d "{\"idLambda\":\"${ID_LAMBDA}\", \"datosBase64\":\"${DATA_BASE64}\"}"
```

### 4. Consultar resultado

```bash
ID_ENCARGO="<uuid-del-encargo>"
curl http://localhost:8080/resultado/${ID_ENCARGO}
```

