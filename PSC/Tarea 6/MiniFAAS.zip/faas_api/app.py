import base64
import json
import logging
import os
import uuid
from pathlib import Path
from typing import Any, Optional

import httpx
from fastapi import (
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    UploadFile,
    status,
)
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("faas_api")

STORAGE_URL = os.getenv("STORAGE_URL", "http://faas-storage:8000")
EXECUTION_URL = os.getenv("EXECUTION_URL", "http://faas-execution:8001")
DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))
HTTP_TIMEOUT = 10.0

app = FastAPI(title="faas-api")


class LambdaInfo(BaseModel):
    idLambda: uuid.UUID
    nombre: str
    runtime: str

    class Config:
        populate_by_name = True


class EncargoRequest(BaseModel):
    idLambda: uuid.UUID = Field(alias="idLambda")
    datosBase64: str = Field(alias="datosBase64")

    class Config:
        populate_by_name = True


class EncargoCreated(BaseModel):
    idEncargo: uuid.UUID = Field(alias="idEncargo")

    class Config:
        populate_by_name = True


class ResultadoResponse(BaseModel):
    status: str
    resultado: Optional[dict[str, Any]] = None

    class Config:
        populate_by_name = True


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


async def get_http_client() -> httpx.AsyncClient:
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
        yield client


@app.post(
    "/guardar_lambda",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
)
async def guardar_lambda(
    file: UploadFile = File(...),
    meta: str = Form(...),
    client: httpx.AsyncClient = Depends(get_http_client),
) -> dict:
    try:
        json.loads(meta)
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Meta inválido") from exc

    files = {
        "file": (file.filename or "lambda.py", await file.read(), file.content_type),
    }
    data = {"meta": meta}

    try:
        resp = await client.post(f"{STORAGE_URL}/lambdas", files=files, data=data)
    except httpx.RequestError as exc:
        logger.error("Error llamando a storage: %s", exc)
        raise HTTPException(status_code=502, detail="Error llamando a storage") from exc

    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)

    return resp.json()


@app.get("/lambdas", response_model=list[LambdaInfo])
async def listar_lambdas(
    client: httpx.AsyncClient = Depends(get_http_client),
) -> list[LambdaInfo]:
    try:
        resp = await client.get(f"{STORAGE_URL}/lambdas")
    except httpx.RequestError as exc:
        logger.error("Error llamando a storage: %s", exc)
        raise HTTPException(status_code=502, detail="Error llamando a storage") from exc

    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)

    data = resp.json()
    return [LambdaInfo(**item) for item in data]


@app.post(
    "/dejar_encargo",
    response_model=EncargoCreated,
    status_code=status.HTTP_201_CREATED,
)
async def dejar_encargo(
    encargo: EncargoRequest,
    client: httpx.AsyncClient = Depends(get_http_client),
) -> EncargoCreated:
    raw = base64.b64decode(encargo.datosBase64.encode("utf-8"))

    input_id = uuid.uuid4()
    input_dir = DATA_DIR / "inputs"
    input_dir.mkdir(parents=True, exist_ok=True)
    input_path = input_dir / f"{input_id}.bin"
    input_path.write_bytes(raw)

    payload = {"idLambda": str(encargo.idLambda), "inputRef": str(input_path)}

    try:
        resp = await client.post(f"{EXECUTION_URL}/encargos", json=payload)
    except httpx.RequestError as exc:
        logger.error("Error llamando a execution: %s", exc)
        raise HTTPException(status_code=502, detail="Error llamando a execution") from exc

    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)

    data = resp.json()
    return EncargoCreated(idEncargo=data["idEncargo"])


@app.get("/resultado/{id_encargo}", response_model=ResultadoResponse)
async def obtener_resultado(
    id_encargo: uuid.UUID,
    client: httpx.AsyncClient = Depends(get_http_client),
) -> ResultadoResponse:
    try:
        resp = await client.get(f"{STORAGE_URL}/encargos/{id_encargo}/resultado")
    except httpx.RequestError as exc:
        logger.error("Error llamando a storage: %s", exc)
        raise HTTPException(status_code=502, detail="Error llamando a storage") from exc

    if resp.status_code == 404:
        raise HTTPException(status_code=404, detail="Encargo no encontrado")
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)

    data = resp.json()
    return ResultadoResponse(status=data["status"], resultado=data.get("resultado"))

