import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from db import get_session
from models import Encargo, EncargoStatus, LambdaFunction, Resultado

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("faas_storage")

DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))

app = FastAPI(title="faas-storage")


class LambdaMeta(BaseModel):
    nombre: str
    runtime: str
    ownerId: Optional[str] = Field(default=None, alias="ownerId")


class LambdaSummary(BaseModel):
    idLambda: uuid.UUID = Field(alias="idLambda")
    nombre: str
    runtime: str

    class Config:
        populate_by_name = True


class ResultadoIn(BaseModel):
    exitCode: int = Field(alias="exitCode")
    stdout: str
    stderr: str
    output: Optional[str] = None

    class Config:
        populate_by_name = True


class ResultadoInfo(BaseModel):
    exitCode: int
    stdoutRef: str
    stderrRef: str
    outputRef: Optional[str] = None

    class Config:
        populate_by_name = True


class EncargoResultadoResponse(BaseModel):
    status: EncargoStatus
    resultado: Optional[ResultadoInfo] = None


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/lambdas", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_lambda(
    file: UploadFile = File(...),
    meta: str = Form(...),
    db: Session = Depends(get_session),
) -> dict:
    try:
        meta_obj = LambdaMeta.model_validate_json(meta)
    except Exception as exc:
        logger.error("Error parsing meta: %s", exc)
        raise HTTPException(status_code=400, detail="Meta inválido") from exc

    lambda_id = uuid.uuid4()
    lambda_dir = DATA_DIR / "lambdas" / str(lambda_id)
    lambda_dir.mkdir(parents=True, exist_ok=True)

    extension = Path(file.filename or "lambda.bin").suffix or ".bin"
    code_path = lambda_dir / f"lambda{extension}"

    content = await file.read()
    with code_path.open("wb") as f:
        f.write(content)

    lf = LambdaFunction(
        id=lambda_id,
        nombre=meta_obj.nombre,
        runtime=meta_obj.runtime,
        owner_id=meta_obj.ownerId,
        code_ref=str(code_path),
    )
    db.add(lf)
    db.commit()
    logger.info("Lambda creada %s en %s", lambda_id, code_path)
    return {"idLambda": str(lambda_id)}


@app.get("/lambdas", response_model=list[LambdaSummary])
def list_lambdas(db: Session = Depends(get_session)) -> list[LambdaSummary]:
    lambdas = db.query(LambdaFunction).order_by(LambdaFunction.created_at).all()
    return [
        LambdaSummary(
            idLambda=l.id,
            nombre=l.nombre,
            runtime=l.runtime,
        )
        for l in lambdas
    ]


@app.get("/lambdas/{id_lambda}/code")
def get_lambda_code(
    id_lambda: uuid.UUID, db: Session = Depends(get_session)
) -> FileResponse:
    lf: Optional[LambdaFunction] = db.get(LambdaFunction, id_lambda)
    if lf is None:
        raise HTTPException(status_code=404, detail="Lambda no encontrada")
    path = Path(lf.code_ref)
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Archivo no encontrado")
    return FileResponse(path)


@app.post(
    "/encargos/{id_encargo}/resultado",
    response_model=dict,
    status_code=status.HTTP_200_OK,
)
def set_encargo_resultado(
    id_encargo: uuid.UUID,
    data: ResultadoIn,
    db: Session = Depends(get_session),
) -> dict:
    encargo: Optional[Encargo] = db.get(Encargo, id_encargo)
    if encargo is None:
        raise HTTPException(status_code=404, detail="Encargo no encontrado")

    result_dir = DATA_DIR / "results" / str(id_encargo)
    result_dir.mkdir(parents=True, exist_ok=True)

    max_len = 64_000

    stdout_ref = result_dir / "stdout.txt"
    stderr_ref = result_dir / "stderr.txt"
    output_ref: Optional[Path] = (
        result_dir / "output.txt" if data.output is not None else None
    )

    stdout_content = data.stdout[:max_len]
    stderr_content = data.stderr[:max_len]

    stdout_ref.write_text(stdout_content, encoding="utf-8")
    stderr_ref.write_text(stderr_content, encoding="utf-8")

    if output_ref is not None:
        output_ref.write_text(data.output[:max_len], encoding="utf-8")

    resultado: Optional[Resultado] = db.get(Resultado, id_encargo)
    if resultado is None:
        resultado = Resultado(
            encargo_id=id_encargo,
            exit_code=data.exitCode,
            stdout_ref=str(stdout_ref),
            stderr_ref=str(stderr_ref),
            output_ref=str(output_ref) if output_ref is not None else None,
        )
        db.add(resultado)
    else:
        resultado.exit_code = data.exitCode
        resultado.stdout_ref = str(stdout_ref)
        resultado.stderr_ref = str(stderr_ref)
        resultado.output_ref = str(output_ref) if output_ref is not None else None

    encargo.status = EncargoStatus.OK if data.exitCode == 0 else EncargoStatus.ERROR
    encargo.finished_at = datetime.now(timezone.utc)
    if data.exitCode != 0 and stderr_content:
        encargo.error_msg = stderr_content

    db.commit()
    logger.info("Resultado guardado para encargo %s", id_encargo)
    return {"ok": True}


@app.get(
    "/encargos/{id_encargo}/resultado",
    response_model=EncargoResultadoResponse,
)
def get_encargo_resultado(
    id_encargo: uuid.UUID,
    db: Session = Depends(get_session),
) -> EncargoResultadoResponse:
    encargo: Optional[Encargo] = db.get(Encargo, id_encargo)
    if encargo is None:
        raise HTTPException(status_code=404, detail="Encargo no encontrado")

    resultado: Optional[Resultado] = encargo.resultado

    if resultado is None:
        return EncargoResultadoResponse(status=encargo.status, resultado=None)

    return EncargoResultadoResponse(
        status=encargo.status,
        resultado=ResultadoInfo(
            exitCode=resultado.exit_code,
            stdoutRef=resultado.stdout_ref,
            stderrRef=resultado.stderr_ref,
            outputRef=resultado.output_ref,
        ),
    )

