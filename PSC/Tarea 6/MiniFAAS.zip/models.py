import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class EncargoStatus(str, enum.Enum):
    PENDIENTE = "PENDIENTE"
    EN_EJECUCION = "EN_EJECUCION"
    OK = "OK"
    ERROR = "ERROR"


class LambdaFunction(Base):
    __tablename__ = "lambdas"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    nombre: Mapped[str] = mapped_column(String(255), nullable=False)
    runtime: Mapped[str] = mapped_column(String(50), nullable=False)
    owner_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    code_ref: Mapped[str] = mapped_column(String(1024), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    encargos: Mapped[list["Encargo"]] = relationship(
        back_populates="lambda_fn", cascade="all, delete-orphan"
    )


class Encargo(Base):
    __tablename__ = "encargos"
    __table_args__ = (
        Index("ix_encargos_status", "status"),
        Index("ix_encargos_lambda_id", "lambda_id"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    lambda_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("lambdas.id", ondelete="CASCADE"),
        nullable=False,
    )
    input_ref: Mapped[str] = mapped_column(String(1024), nullable=False)
    status: Mapped[EncargoStatus] = mapped_column(
        Enum(EncargoStatus, name="encargo_status"),
        nullable=False,
        default=EncargoStatus.PENDIENTE,
        server_default=EncargoStatus.PENDIENTE.value,
    )
    worker_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    finished_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    error_msg: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    lambda_fn: Mapped[LambdaFunction] = relationship(back_populates="encargos")
    resultado: Mapped[Optional["Resultado"]] = relationship(
        back_populates="encargo", uselist=False, cascade="all, delete-orphan"
    )


class Resultado(Base):
    __tablename__ = "resultados"

    encargo_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("encargos.id", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
    )
    exit_code: Mapped[int] = mapped_column(Integer, nullable=False)
    stdout_ref: Mapped[str] = mapped_column(String(1024), nullable=False)
    stderr_ref: Mapped[str] = mapped_column(String(1024), nullable=False)
    output_ref: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)

    encargo: Mapped[Encargo] = relationship(back_populates="resultado")

