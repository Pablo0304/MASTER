import os
from typing import Generator, Optional

from sqlalchemy import func, select, update, create_engine
from sqlalchemy.orm import Session, sessionmaker

from models import Base, Encargo, EncargoStatus

DEFAULT_DB_URL = "postgresql+psycopg2://faas:faas@postgres:5432/faas"


def _make_url() -> str:
    return os.getenv("DB_URL", DEFAULT_DB_URL)


engine = create_engine(_make_url(), future=True)
SessionLocal = sessionmaker(
    bind=engine, autoflush=False, autocommit=False, expire_on_commit=False, future=True
)


def get_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    Base.metadata.create_all(bind=engine)


def claim_next_encargo(db: Session, worker_id: str) -> Optional[Encargo]:
    """
    Intenta reclamar de forma atómica un encargo con estado PENDIENTE
    asignándolo al worker dado y marcándolo como EN_EJECUCION.
    Devuelve el encargo reclamado o None si no hay disponible.
    """
    stmt = (
        update(Encargo)
        .where(Encargo.status == EncargoStatus.PENDIENTE)
        .where(Encargo.worker_id.is_(None))
        .order_by(Encargo.created_at)
        .limit(1)
        .values(
            status=EncargoStatus.EN_EJECUCION,
            worker_id=worker_id,
            started_at=func.now(),
        )
        .returning(Encargo)
    )
    result = db.execute(stmt)
    encargo = result.scalars().first()
    if encargo is None:
        db.rollback()
        return None
    db.commit()
    db.refresh(encargo)
    return encargo

