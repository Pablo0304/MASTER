import base64
import json
import time
from pathlib import Path

import requests

API_URL = "http://localhost:8080"


def upload_lambda() -> str:
    code = """import sys

def main():
    data = sys.stdin.read().strip()
    n = int(data)
    print(n * 2)

if __name__ == "__main__":
    main()
"""
    lambda_path = Path("lambda_test.py")
    lambda_path.write_text(code, encoding="utf-8")

    meta = {"nombre": "doble_e2e", "runtime": "python", "ownerId": None}

    with lambda_path.open("rb") as f:
        files = {"file": ("lambda_test.py", f, "text/x-python")}
        data = {"meta": json.dumps(meta)}
        resp = requests.post(f"{API_URL}/guardar_lambda", files=files, data=data)
    resp.raise_for_status()
    lambda_id = resp.json()["idLambda"]
    return lambda_id


def list_lambdas_and_check(lambda_id: str) -> None:
    resp = requests.get(f"{API_URL}/lambdas")
    resp.raise_for_status()
    lambdas = resp.json()
    ids = {item["idLambda"] for item in lambdas}
    assert lambda_id in ids, "Lambda subida no aparece en la lista"


def create_encargo(lambda_id: str, value: int) -> str:
    raw = str(value).encode("utf-8")
    datos_base64 = base64.b64encode(raw).decode("ascii")
    payload = {"idLambda": lambda_id, "datosBase64": datos_base64}
    resp = requests.post(f"{API_URL}/dejar_encargo", json=payload)
    resp.raise_for_status()
    return resp.json()["idEncargo"]


def wait_for_result(id_encargo: str, expected_stdout: str, timeout_seconds: float = 60.0):
    start = time.time()
    while True:
        resp = requests.get(f"{API_URL}/resultado/{id_encargo}")
        if resp.status_code == 404:
            raise RuntimeError("Encargo no encontrado")
        resp.raise_for_status()
        data = resp.json()
        status_str = data["status"]
        if status_str in ("OK", "ERROR"):
            if status_str != "OK":
                raise AssertionError(f"Encargo terminó en estado {status_str}")
            resultado = data.get("resultado") or {}
            stdout_ref = resultado.get("stdoutRef")
            if not stdout_ref:
                raise AssertionError("stdoutRef ausente en resultado")
            stdout = Path(stdout_ref).read_text(encoding="utf-8").strip()
            assert (
                stdout == expected_stdout
            ), f"stdout esperado {expected_stdout!r}, obtenido {stdout!r}"
            return
        if time.time() - start > timeout_seconds:
            raise TimeoutError("Timeout esperando resultado")
        time.sleep(2.0)


def main():
    lambda_id = upload_lambda()
    print("Lambda subida:", lambda_id)
    list_lambdas_and_check(lambda_id)
    print("Lambda aparece en listado")

    id_encargo = create_encargo(lambda_id, 21)
    print("Encargo creado:", id_encargo)

    wait_for_result(id_encargo, "42")
    print("E2E OK: resultado correcto")


if __name__ == "__main__":
    main()

