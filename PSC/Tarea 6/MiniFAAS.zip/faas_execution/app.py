import logging
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Query, Response, status
from pydantic import BaseModel, Field
from sqlalchemy import update
from sqlalchemy.orm import Session

from db import get_session, claim_next_encargo
from models import Encargo, EncargoStatus

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("faas_execution")

CLAIM_TIMEOUT_SECONDS = int(os.getenv("CLAIM_TIMEOUT_SECONDS", "300"))

app = FastAPI(title="faas-execution")


class EncargoCreate(BaseModel):
    idLambda: uuid.UUID = Field(alias="idLambda")
    inputRef: str = Field(alias="inputRef")

    class Config:
        populate_by_name = True


class EncargoCreatedResponse(BaseModel):
    idEncargo: uuid.UUID = Field(alias="idEncargo")

    class Config:
        populate_by_name = True


class EncargoNextResponse(BaseModel):
    idEncargo: uuid.UUID
    idLambda: uuid.UUID
    inputRef: str

    class Config:
        populate_by_name = True


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post(
    "/encargos",
    response_model=EncargoCreatedResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_encargo(
    data: EncargoCreate,
    db: Session = Depends(get_session),
) -> EncargoCreatedResponse:
    encargo = Encargo(
        lambda_id=data.idLambda,
        input_ref=data.inputRef,
        status=EncargoStatus.PENDIENTE,
    )
    db.add(encargo)
    db.commit()
    db.refresh(encargo)
    logger.info("Encargo creado %s para lambda %s", encargo.id, data.idLambda)
    return EncargoCreatedResponse(idEncargo=encargo.id)


@app.get("/encargos/next", response_model=Optional[EncargoNextResponse])
def get_next_encargo(
    workerId: str = Query(..., alias="workerId"),
    db: Session = Depends(get_session),
) -> Response | EncargoNextResponse:
    max_retries = 3
    encargo: Optional[Encargo] = None

    for _ in range(max_retries):
        encargo = claim_next_encargo(db, workerId)
        if encargo is not None:
            break

    if encargo is None:
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    return EncargoNextResponse(
        idEncargo=encargo.id,
        idLambda=encargo.lambda_id,
        inputRef=encargo.input_ref,
    )


@app.post("/encargos/{id_encargo}/heartbeat", status_code=status.HTTP_200_OK)
def heartbeat_encargo(
    id_encargo: uuid.UUID,
    workerId: str = Query(..., alias="workerId"),
    db: Session = Depends(get_session),
) -> dict:
    encargo: Optional[Encargo] = db.get(Encargo, id_encargo)
    if encargo is None:
        raise HTTPException(status_code=404, detail="Encargo no encontrado")
    if encargo.worker_id != workerId:
        raise HTTPException(status_code=409, detail="Worker incorrecto")
    return {"ok": True}


@app.post("/encargos/recover", status_code=status.HTTP_200_OK)
def recover_encargos(
    db: Session = Depends(get_session),
) -> dict:
    limit_time = datetime.now(timezone.utc) - timedelta(seconds=CLAIM_TIMEOUT_SECONDS)

    stmt = (
        update(Encargo)
        .where(Encargo.status == EncargoStatus.EN_EJECUCION)
        .where(Encargo.started_at < limit_time)
        .values(
            status=EncargoStatus.PENDIENTE,
            worker_id=None,
            started_at=None,
        )
    )
    result = db.execute(stmt)
    count = result.rowcount or 0
    db.commit()
    logger.info("Reencolados %s encargos", count)
    return {"recovered": count}

