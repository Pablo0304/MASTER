import logging
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Optional

import requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("worker")

EXECUTION_URL = os.getenv("EXECUTION_URL", "http://faas-execution:8001")
STORAGE_URL = os.getenv("STORAGE_URL", "http://faas-storage:8000")
WORKER_ID = os.getenv("WORKER_ID", str(uuid.uuid4()))
POLL_INTERVAL_SECONDS = float(os.getenv("POLL_INTERVAL_SECONDS", "2.0"))
EXEC_TIMEOUT_SECONDS = float(os.getenv("EXEC_TIMEOUT_SECONDS", "10.0"))
DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))

MAX_STREAM_LEN = 64_000


def fetch_next_job() -> Optional[dict]:
    url = f"{EXECUTION_URL}/encargos/next"
    params = {"workerId": WORKER_ID}
    resp = requests.get(url, params=params)
    if resp.status_code == 204:
        return None
    resp.raise_for_status()
    return resp.json()


def download_lambda(id_lambda: str, work_dir: Path) -> Path:
    url = f"{STORAGE_URL}/lambdas/{id_lambda}/code"
    resp = requests.get(url, stream=True)
    resp.raise_for_status()
    work_dir.mkdir(parents=True, exist_ok=True)
    lambda_path = work_dir / "lambda.py"
    with lambda_path.open("wb") as f:
        for chunk in resp.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)
    return lambda_path


def read_input(input_ref: str) -> bytes:
    path = Path(input_ref)
    return path.read_bytes()


def execute_lambda(lambda_path: Path, input_data: bytes) -> tuple[int, str, str]:
    proc = subprocess.run(
        [sys.executable, str(lambda_path)],
        input=input_data,
        capture_output=True,
        timeout=EXEC_TIMEOUT_SECONDS,
    )
    stdout = proc.stdout.decode("utf-8", errors="replace")[:MAX_STREAM_LEN]
    stderr = proc.stderr.decode("utf-8", errors="replace")[:MAX_STREAM_LEN]
    return proc.returncode, stdout, stderr


def send_result(
    id_encargo: str,
    exit_code: int,
    stdout: str,
    stderr: str,
    output: Optional[str] = None,
) -> None:
    url = f"{STORAGE_URL}/encargos/{id_encargo}/resultado"
    payload = {
        "exitCode": exit_code,
        "stdout": stdout,
        "stderr": stderr,
        "output": output,
    }
    resp = requests.post(url, json=payload)
    resp.raise_for_status()


def run_loop() -> None:
    logger.info("Worker %s iniciado", WORKER_ID)
    while True:
        try:
            job = fetch_next_job()
        except Exception as exc:
            logger.error("Error obteniendo trabajo: %s", exc)
            time.sleep(POLL_INTERVAL_SECONDS)
            continue

        if job is None:
            time.sleep(POLL_INTERVAL_SECONDS)
            continue

        id_encargo = job["idEncargo"]
        id_lambda = job["idLambda"]
        input_ref = job["inputRef"]

        logger.info("Procesando encargo %s lambda %s", id_encargo, id_lambda)

        work_dir = DATA_DIR / "work" / str(id_encargo)
        lambda_path = None

        try:
            lambda_path = download_lambda(id_lambda, work_dir)
            input_data = read_input(input_ref)
            exit_code, stdout, stderr = execute_lambda(lambda_path, input_data)
        except subprocess.TimeoutExpired:
            exit_code = 124
            stdout = ""
            stderr = "Execution timeout"
        except Exception as exc:
            logger.exception("Error ejecutando encargo %s: %s", id_encargo, exc)
            exit_code = 1
            stdout = ""
            stderr = str(exc)[:MAX_STREAM_LEN]

        try:
            send_result(id_encargo, exit_code, stdout, stderr)
        except Exception as exc:
            logger.error("Error enviando resultado de %s: %s", id_encargo, exc)

        try:
            if lambda_path and lambda_path.parent.exists():
                for child in lambda_path.parent.iterdir():
                    if child.is_file():
                        child.unlink()
        except Exception:
            pass


if __name__ == "__main__":
    run_loop()

